# Entrega Semanal 01 — Linguagem de Diálogo para Chatbots (Grupo 02)

## Resumo
- Implementado tradutor de DSL ChatFlow -> IR (JSON)
- Simulador de 3 fluxos completos
- Exemplos de regras e sequências de intents

## Próximos passos
- Validações da DSL (intents desconhecidas, estados inalcançáveis)
- Diagrama DOT opcional
