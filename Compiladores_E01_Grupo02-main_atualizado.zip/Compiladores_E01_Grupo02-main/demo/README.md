# Demo do Sistema (até 5 min)
- Grave um vídeo `demo.mp4` mostrando a execução dos 3 fluxos.
- Dica: use um gravador de tela, rode os comandos de simulação e mostre os resultados no terminal.
- Formato exigido: `.mp4`.
